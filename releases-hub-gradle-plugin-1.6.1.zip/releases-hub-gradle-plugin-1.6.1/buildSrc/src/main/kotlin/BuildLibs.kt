object BuildLibs {
    // https://github.com/maxirosson/jdroid-gradle-plugin/releases
    const val JDROID_GRADLE_PROJECT_PLUGIN = "com.jdroidtools:jdroid-gradle-project-plugin:2.4.0-SNAPSHOT"
    const val JDROID_GRADLE_ROOT_PLUGIN = "com.jdroidtools:jdroid-gradle-root-plugin:2.4.0-SNAPSHOT"
}
