package com.releaseshub.gradle.plugin.artifacts

enum class ArtifactUpgradeStatus {
    PENDING_UPGRADE,
    ALREADY_UPGRADED,
    NOT_FOUND
}
