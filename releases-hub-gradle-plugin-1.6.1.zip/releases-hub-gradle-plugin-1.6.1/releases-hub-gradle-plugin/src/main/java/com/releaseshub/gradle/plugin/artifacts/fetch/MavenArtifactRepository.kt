package com.releaseshub.gradle.plugin.artifacts.fetch

class MavenArtifactRepository(var name: String, var url: String)
