package com.releaseshub.gradle.plugin.artifacts.fetch

enum class ReleaseLifeCycle {
    UNKNOWN,
    ALPHA,
    BETA,
    RC,
    STABLE;
}
