package com.releaseshub.gradle.plugin.artifacts.fetch

import java.util.Date

class VersioningMetadata {
    var versions: List<Version>? = null
    var lastUpdated: Date? = null
}
