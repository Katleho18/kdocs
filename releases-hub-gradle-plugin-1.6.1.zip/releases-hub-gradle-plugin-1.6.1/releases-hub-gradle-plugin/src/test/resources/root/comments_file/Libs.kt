object Libs {
    // this is a comment

    // const val JUNIT = "junit:junit:4.13"
}
