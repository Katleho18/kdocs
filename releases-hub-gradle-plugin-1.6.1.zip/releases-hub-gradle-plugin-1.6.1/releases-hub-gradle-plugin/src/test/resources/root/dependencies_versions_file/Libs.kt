object Libs {

    // https://github.com/maxirosson/jdroid-java/releases
    const val JDROID_JAVA_CORE = "com.jdroidtools:jdroid-java-core:3.0.0"

    // https://github.com/junit-team/junit4/releases
    const val JUNIT = "junit:junit:4.13"
}
