object Sample {


	fun hello() {
		throw KotlinNullPointerException()
	}
}